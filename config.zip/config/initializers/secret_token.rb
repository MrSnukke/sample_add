# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SampleApp::Application.config.secret_token = 'cdb81fb1b6e9833f8a8f5d06559398a20a2f92983f766527e8179fb7b79015380ad49781857662a806210be79412847e47de03525c809db7f21794e2ba8960ac'
